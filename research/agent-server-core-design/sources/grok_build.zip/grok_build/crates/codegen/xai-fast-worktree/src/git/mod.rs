//! Git operations used by fast worktree creation.
//!
//! This module isolates git-specific functionality (worktree creation, status, index refresh)
//! from filesystem copy logic and orchestration.

pub(crate) mod checkout;
pub(crate) mod discovery;
pub(crate) mod index;
pub(crate) mod status;
pub(crate) mod worktree;

pub(crate) use checkout::checkout_ref;
pub(crate) use checkout::{git_clean_fd, git_reset_hard_command};
// Only consumed by the Linux-only snapshot finalize path.
#[cfg(target_os = "linux")]
pub(crate) use checkout::{has_staged_changes, worktree_at_ref, worktree_has_tracked_changes};
pub(crate) use discovery::{find_worktree_root, get_head_commit};
pub(crate) use index::{copy_git_index, update_index_stats};
pub(crate) use status::get_modified_files;
pub(crate) use worktree::worktree_add_no_checkout;
