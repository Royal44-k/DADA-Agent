# @xai-official/grok-linux-x64

Platform-specific binary for [`@xai-official/grok`](https://www.npmjs.com/package/@xai-official/grok) on linux-x64.

Do not install this package directly. Install the main package instead:

```sh
npm install -g @xai-official/grok
```

The main package will automatically pull the correct binary for your platform via `optionalDependencies`.
